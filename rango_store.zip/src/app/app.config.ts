import { InjectionToken } from "@angular/core";

export let APP_CONFIG = new InjectionToken<AppConfig>("app.config");

export interface FirebaseConfig {
  apiKey: string,
  authDomain: string,
  databaseURL: string,
  projectId: string,
  storageBucket: string,
  messagingSenderId: string,
  webApplicationId: string
}

export interface AppConfig {
  appName: string;
  apiBase: string;
  googleApiKey: string;
  oneSignalAppId: string;
  oneSignalGPSenderId: string;
  stripeKey: string;
  availableLanguages: Array<any>;
  firebaseConfig: FirebaseConfig;
  demoMode: boolean;
}

export const BaseAppConfig: AppConfig = {
  appName: "Cookfu Store",
  apiBase: "http://opuslabs.in:9081/",
  googleApiKey: "AIzaSyC4xQ0n-BwL_gODzdOTI6eqmzABT7XtF9Y",
  oneSignalAppId: "220205f9-4072-4487-8a15-b157136e8786",
  oneSignalGPSenderId: "637446709495",
  stripeKey: "pk_live_REwn0xwFgQThJbX4Hi2gComm",
  demoMode: true,
  availableLanguages: [{
    code: 'en',
    name: 'English'
  }, {
    code: 'ar',
    name: 'Arabic'
  }],
  firebaseConfig: {
    webApplicationId: "637446709495-sn78ov9tjqlu7spekcdsns2o33p6fs29.apps.googleusercontent.com",
    apiKey: "AIzaSyC4xQ0n-BwL_gODzdOTI6eqmzABT7XtF9Y",
    authDomain: "dentist-58abe.firebaseapp.com",
    databaseURL: "https://dentist-58abe.firebaseio.com",
    projectId: "dentist-58abe",
    storageBucket: "dentist-58abe.appspot.com",
    messagingSenderId: "637446709495"
  }
};
