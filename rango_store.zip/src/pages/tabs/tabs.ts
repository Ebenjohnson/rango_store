import { Component } from '@angular/core';
import { OrdersPage } from '../orders/orders';
import { ItemsPage } from '../items/items';
import { AccountPage } from '../account/account';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = OrdersPage;
  //tab2Root = DeliveryPage;
  tab2Root = ItemsPage;
  tab3Root = AccountPage;

  constructor() {

  }

}
