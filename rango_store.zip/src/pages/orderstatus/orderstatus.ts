import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
//import { TabsPage } from '../tabs/tabs';

@Component({
  selector: 'page-orderstatus',
  templateUrl: 'orderstatus.html'
})
export class OrderstatusPage {

  constructor(public navCtrl: NavController) {

  }

//tabs(){
   //this.navCtrl.setRoot(TabsPage);
   //}  
}
