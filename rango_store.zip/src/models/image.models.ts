export class Image {
	src: string;
	title: string;
	alt: string;
}