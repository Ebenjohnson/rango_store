export class Constants {
	static KEY_USER: string = "ks_user";
	static KEY_TOKEN: string = "ks_token";
	static KEY_SETTING: string = "ks_setting";
	static KEY_LOCATION: string = "ks_location";
	static KEY_REFINE_SETTING: string = "ks_refine_setting";
	static PAYMENT_GATEWAYS: string = "ks_pgs";
	static SHIPPING_LINES: string = "ks_sls";
	static STORE_DETAILS: string = "ks_sd";
	static KEY_DEFAULT_LANGUAGE: string = "ks_lng";
	static KEY_LOCALE: string = "ks_locale";
}