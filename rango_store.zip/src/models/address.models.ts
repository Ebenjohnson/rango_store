export class Address {
  id: number;
  title: string;
  address: string;
  longitude: string;
  latitude: string;
  user_id: number;
  created_at: string;
  updated_at: string;
}