import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from "rxjs/Observable";
import { APP_CONFIG, AppConfig } from "../app/app.config";
import { Country } from '../models/country.models';
import { StoreRequest } from '../models/store-request.models';
import { StoreResponse } from '../models/store-response.models';
import { ResetPasswordResponse } from '../models/reset-password-request.models';
import { AuthResponse } from '../models/auth-response.models';
import { SignInRequest } from '../models/signin-request.models';
import { SignUpRequest } from '../models/signup-request.models';
import { Setting } from '../models/setting.models';
import { Constants } from '../models/constants.models';
import { BaseListResponse } from '../models/base-list.models';
import { Item } from '../models/item.models';
import { Address } from '../models/address.models';
import { PaymentMethod } from '../models/payment-methods.models';
import { EarningResponse } from '../models/earnings-response.models';
import { SupportRequest } from '../models/support-request.models';
import { BankDetail } from '../models/bank-details.models';
import { Order } from '../models/order.models';
import { Helper } from '../models/helper';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/concatMap';
import moment from 'moment';

@Injectable()
export class ClientService {
  private myHeaders: HttpHeaders;

  constructor(@Inject(APP_CONFIG) private config: AppConfig, private http: HttpClient) {
    this.setupHeaders();
  }

  setupHeaders(authToken?: string) {
    //let savedLanguageCode = window.localStorage.getItem(Constants.KEY_DEFAULT_LANGUAGE);
    let token = authToken ? authToken : window.localStorage.getItem(Constants.KEY_TOKEN);
    this.myHeaders = new HttpHeaders(token ? {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': ('Bearer ' + token)
      //,'X-Localization': String(savedLanguageCode ? savedLanguageCode : this.config.availableLanguages[0].code)
    } : {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        //,'X-Localization': String(savedLanguageCode ? savedLanguageCode : this.config.availableLanguages[0].code)
      });
  }

  public updateUser(updateRequest): Observable<{}> {
    return this.http.put<{}>(this.config.apiBase + 'api/user', updateRequest, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getCountries(): Observable<Array<Country>> {
    return this.http.get<Array<Country>>('./assets/json/countries.json').concatMap((data) => {
      // let indiaObj: any = {};
      // for (let index = 0; index < data.length; index++) {
      //   if (!(data[index].callingCodes.length) || data[index].callingCodes[0] == "") {
      //     data.splice(index, 1);
      //   }
      //   if (data[index].alpha2Code === "IN") {
      //     indiaObj = data[index];
      //     data.splice(index, 1);
      //   }
      // }
      // data.splice(0, 0, indiaObj);
      return Observable.of(data);
    });
  }

  public getPaymentMethods(): Observable<Array<PaymentMethod>> {
    return this.http.get<Array<PaymentMethod>>(this.config.apiBase + "api/customer/payment-methods", { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getAddress(id): Observable<Address> {
    return this.http.get<Address>(this.config.apiBase + "api/customer/address/" + id, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getSettings(): Observable<Array<Setting>> {
    return this.http.get<Array<Setting>>(this.config.apiBase + "api/settings", { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getEarnings(): Observable<EarningResponse> {
    return this.http.get<EarningResponse>(this.config.apiBase + "api/earnings", { headers: this.myHeaders }).concatMap(data => {
      if (!data.last_earning_date) {
        data.last_earning_date = String(new Date());
      }
      data.last_earning_date = this.formatDate(data.last_earning_date, Helper.getLocale());
      data.total_earnings = Number(data.total_earnings.toFixed(2));
      return Observable.of(data);
    });
  }

  public orders(past_orders: number, active_orders: number, page: number): Observable<BaseListResponse> {
    let urlParams = new URLSearchParams();
    urlParams.append("past_orders", String(past_orders));
    urlParams.append("active_orders", String(active_orders));
    urlParams.append("page", String(page));
    return this.http.get<BaseListResponse>(this.config.apiBase + 'api/order?' + urlParams.toString(), { headers: this.myHeaders }).concatMap(data => {
      let locale = Helper.getLocale();
      for (let order of data.data) {
        order.scheduled_on = this.formatDateTime(order.scheduled_on, locale);
        order.created_at = this.formatDateTime(order.created_at, locale);
        order.updated_at = this.formatDateTime(order.updated_at, locale);
      }
      return Observable.of(data);
    });
  }

  public getStoreProfile(): Observable<StoreResponse> {
    return this.http.get<StoreResponse>(this.config.apiBase + 'api/store', { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public updateStore(storeRequest: StoreRequest): Observable<StoreResponse> {
    return this.http.put<StoreResponse>(this.config.apiBase + "api/store/update", JSON.stringify(storeRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public updateOrder(id, body): Observable<Order> {
    return this.http.put<Order>(this.config.apiBase + "api/order/" + id, body, { headers: this.myHeaders }).concatMap(data => {
      let locale = Helper.getLocale();
      data.created_at = this.formatDateTime(data.created_at, locale);
      data.updated_at = this.formatDateTime(data.updated_at, locale);
      return Observable.of(data);
    });
  }

  public saveItem(itemRequest): Observable<Item> {
    return this.http.post<Item>(this.config.apiBase + "api/menuitem", JSON.stringify(itemRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public updateItem(itemRequest): Observable<Item> {
    return this.http.post<Item>(this.config.apiBase + "api/menuitem/" + itemRequest.id, JSON.stringify(itemRequest), { headers: this.myHeaders }).concatMap(data => {
      data.available = data.is_available == '1';
      return Observable.of(data);
    });
  }

  public getCategories(): Observable<BaseListResponse> {
    return this.http.get<BaseListResponse>(this.config.apiBase + "api/category", { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getItems(query: string, page): Observable<BaseListResponse> {
    return this.http.get<BaseListResponse>(this.config.apiBase + "api/menuitem?status=" + query + "&page=" + page, { headers: this.myHeaders }).concatMap(data => {
      for (let item of data.data) {
        item.available = item.is_available == '1';
      }
      return Observable.of(data);
    });
  }

  public forgetPassword(resetRequest: any): Observable<ResetPasswordResponse> {
    return this.http.post<ResetPasswordResponse>(this.config.apiBase + "api/forgot-password", JSON.stringify(resetRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public login(loginRequest: SignInRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/login", JSON.stringify(loginRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public loginSocial(socialLoginRequest: any): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/social/login", JSON.stringify(socialLoginRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public signUp(signUpRequest: SignUpRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/register", JSON.stringify(signUpRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public verifyMobile(verifyRequest: any): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.config.apiBase + "api/verify-mobile", JSON.stringify(verifyRequest), { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public contactUs(obj): Observable<SupportRequest> {
    return this.http.post<SupportRequest>(this.config.apiBase + 'api/support', obj, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public saveBankDetails(obj): Observable<BankDetail> {
    return this.http.post<BankDetail>(this.config.apiBase + 'api/bank-detail', obj, { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getBankDetail(): Observable<BankDetail> {
    return this.http.get<BankDetail>(this.config.apiBase + 'api/bank-detail', { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }

  public getStoreRatings(page): Observable<BaseListResponse> {
    return this.http.get<BaseListResponse>(this.config.apiBase + 'api/rating?page=' + page, { headers: this.myHeaders }).concatMap(data => {
      let locale = Helper.getLocale();
      for (let review of data.data) {
        review.rating = Number(review.rating).toFixed(1);
        review.created_at = this.formatDate(review.created_at, locale);
        review.updated_at = this.formatDate(review.updated_at, locale);
      }
      return Observable.of(data);
    });
  }

  private formatDateTime(dateString: string, locale: string): string {
    return moment(dateString).locale(locale).format("ddd, MMM D, HH:mm");
  }

  private formatDate(dateString: string, locale: string): string {
    return moment(dateString).locale(locale).format("DD MMM YYYY");
  }
  public getWhatsappDetails(): Observable<Array<Setting>> {

    return this.http.get<Array<Setting>>('https://dashboard.vtlabs.dev/whatsapp.php?product_name=cookfu', { headers: this.myHeaders }).concatMap(data => {
      return Observable.of(data);
    });
  }
}